#include <iostream>
#include <winsock2.h>
using namespace std;

int main() {
    WSADATA wsa;
    SOCKET server, client;
    struct sockaddr_in serverAddr, clientAddr;
    int clientLen = sizeof(clientAddr);
    char buffer[1024];

    WSAStartup(MAKEWORD(2,2), &wsa);
    server = socket(AF_INET, SOCK_STREAM, 0);

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(8080);

    bind(server, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
    listen(server, 1);
    cout << "Server waiting for connection..." << endl;

    client = accept(server, (struct sockaddr*)&clientAddr, &clientLen);
    cout << "Client connected!" << endl;

    while (true) {
        memset(buffer, 0, sizeof(buffer));
        recv(client, buffer, sizeof(buffer), 0);
        cout << "Client: " << buffer << endl;
        cout << "You: ";
        cin.getline(buffer, sizeof(buffer));
        send(client, buffer, strlen(buffer), 0);
        if (strcmp(buffer, "exit") == 0) break;
    }

    closesocket(client);
    closesocket(server);
    WSACleanup();
    return 0;
}
