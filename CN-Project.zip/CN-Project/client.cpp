#include <iostream>
#include <winsock2.h>
using namespace std;

int main() {
    WSADATA wsa;
    SOCKET client;
    struct sockaddr_in serverAddr;
    char buffer[1024];

    WSAStartup(MAKEWORD(2,2), &wsa);
    client = socket(AF_INET, SOCK_STREAM, 0);

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    serverAddr.sin_port = htons(8080);

    connect(client, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
    cout << "Connected to Server!" << endl;

    while (true) {
        cout << "You: ";
        cin.getline(buffer, sizeof(buffer));
        send(client, buffer, strlen(buffer), 0);
        if (strcmp(buffer, "exit") == 0) break;
        memset(buffer, 0, sizeof(buffer));
        recv(client, buffer, sizeof(buffer), 0);
        cout << "Server: " << buffer << endl;
    }

    closesocket(client);
    WSACleanup();
    return 0;
}
