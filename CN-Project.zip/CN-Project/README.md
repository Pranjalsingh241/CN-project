# CN-Project
### Simple Client-Server Chat Application (C++)

**Created by:** Aman Paswan  
**Language:** C++ (Windows Socket Programming)  
**Type:** Computer Networks Mini Project  

---

## 📘 Description
This project demonstrates a basic chat between a server and a client using TCP sockets (Winsock2) in C++.  
Both the client and server can send and receive text messages until one types "exit".

---

## ⚙️ How to Run
1. Install MinGW or Code::Blocks with g++ compiler on Windows.  
2. Open a terminal in this folder and compile both programs:

```bash
g++ server.cpp -o server -lws2_32
g++ client.cpp -o client -lws2_32
```

3. Run in two terminals:
   - First terminal → `./server`
   - Second terminal → `./client`

4. Start chatting! Type messages and press Enter.  
   Type `exit` to end the chat.

---

**Project by:** Aman Paswan  
